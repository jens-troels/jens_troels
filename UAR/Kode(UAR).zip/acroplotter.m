clear, clc, close all


fid = fopen("acro.dat",'r');
datacell = textscan(fid, '%f%f%f%f', 'HeaderLines', 1, 'Collect', 1);
fclose(fid);
data1 = datacell{1};


%Adjust start and end for data
time=[0: 0.001 :13.5];
start=1;
ending=13501;
theta1=data1(start:ending,1);
theta2=data1(start:ending,2);
omega1=data1(start:ending,3);
omega2=data1(start:ending,4);

subplot(4,1,1)
plot(time,theta1)
xlabel('Time [s]')
ylabel('Angle [rad]')
subplot(4,1,2)
plot(time,theta2)
xlabel('Time [s]')
ylabel('Angle [rad]')
subplot(4,1,3)
plot(time,omega1)
xlabel('Time [s]')
ylabel('Velocity [rad/s]')
subplot(4,1,4)
plot(time,omega2)
xlabel('Time [s]')
ylabel('Velocity [rad/s]')
