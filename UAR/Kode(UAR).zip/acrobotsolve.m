clear, clc, close all
syms l1 l2 lc1 lc2 m1 m2 g theta1 theta2 omega1 omega2 alpha1 alpha2 I1 I2 tau
%%
%Defining constants to make state space easier
x = m2*l1*lc2;
a = m1*g*lc1;
b = m2*g*lc2;
c = m2*g;
d = m2*l1^2;
e = m2*l2*g;

k = m1 * lc1 * g;
l = m2 * l1 * g;
%%
eq1 = (I1 + I2 + m2*l1^2 + 2*m2*l1*lc2*cos(theta2))*alpha1 + (I2 + m2*l1*lc2*cos(theta2))*alpha2-2*m2*l1*lc2*sin(theta2)*omega1*omega2-m2*l1*lc2*sin(theta2)*omega2^2+(m1*lc1+m2*l1)*g*sin(theta1)+m2*l2*g*sin(theta1+theta2)==0;
eq2 = (I2 + m2*l1*lc2*cos(theta2))*alpha1 + I2*alpha2 + m2*l1*lc2*sin(theta2)*omega1^2 + m2*l2*g*sin(theta1+theta2) == tau;
a1Sol=isolate(eq1,alpha1);
eqn2 = subs(eq2,lhs(a1Sol),rhs(a1Sol));
a2Sol=isolate(eqn2,alpha2)
eqn1 = subs(a1Sol,lhs(a2Sol),rhs(a2Sol))