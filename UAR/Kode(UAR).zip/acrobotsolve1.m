clear, clc, close all
syms l1 l2 lc1 lc2 m1 m2 g theta1 theta2 omega1 omega2 alpha1 alpha2 I1 I2 tau
%%
l1 = 1;
l2 = 1;
lc1 = l1/2;
lc2 = l2/2;
m1 = 1;
m2 = 1;
g = 9.82;
theta1 = 0;
theta2 = 0;
omega1 = 0;
omega2 = 0;
alpha1 = 0;
alpha2 = 0;
I1 = 1
I2 = 1
tau = 0;
%%
%Defining state matrices for state space
H = [I1 + I2 + m2*l1^2 + 2*m2*l1*lc2*cos(theta2) I2 + m2*l1*lc2*cos(theta2); I2 + m2*l1*lc2*cos(theta2) I2]
G = [(m1*lc1+m2*l1)*g*sin(theta1) + m2*g*l2*sin(theta1+theta2); m2*g*l2*sin(theta1+theta2)]
Bs = [0; 1]
dG = [-g*(m1*lc1+m2*l1+m2*l2) -m2*g*l2; -m2*g*l2 -m2*g*l2]
A = [zeros(2,2) eye(2); -inv(H)*dG zeros(2,2)]
B = [zeros(2,1); inv(H)*Bs]

%%
Co = ctrb(A,B);
rank(Co) == rank(A)
%%
%LQR
Q = [5 0 0 0; 0 1000 0 0; 0 0 5 0; 0 0 0 1000];
R = [1];
[K,P,E]=lqr(A,B,Q,R)

%%
sys3 = ss(A-B*K, eye(4), eye(4), eye(4));
t = 0:0.01:4;
x = initial(sys3,[0.1745;0;-0.1745;0],t);
x1 = [1 0 0 0]*x';
x2 = [0 1 0 0]*x';
x3 = [0 0 1 0]*x';
x4 = [0 0 0 1]*x';

figure
subplot(4,1,1); plot(t,x1); grid
xlabel('t (sec)'); ylabel('theta1 (rad)');
subplot(4,1,2); plot(t,x2); grid
xlabel('t (sec)'); ylabel('theta2 (rad)');
subplot(4,1,3); plot(t,x3); grid
xlabel('t (sec)'); ylabel('omega1 (rad/s)');
subplot(4,1,4); plot(t,x4); grid
xlabel('t (sec)'); ylabel('omega2 (rad/s)');